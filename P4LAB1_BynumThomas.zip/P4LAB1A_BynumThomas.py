#Thomas Bynum
#07/09/2025
#P4LAB1A
#Write a turtle graphics programs that draws a triangle and a square using loops.

import turtle

t = turtle.Turtle()
t.shape("turtle")  
t.speed(1)

sides_drawn = 0
while sides_drawn < 4:
    t.forward(100)
    t.right(90)
    sides_drawn = sides_drawn + 1

t.penup()
t.goto(150, 0)
t.pendown()

for side in range(3):
    t.forward(100)
    t.left(120)


turtle.done()
