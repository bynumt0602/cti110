#Thomas Bynum
#07/09/2025
#P4LAB1B
#Using turtle graphics, write a program that displays your first and last initials. 

import turtle

t = turtle.Turtle()
t.shape("turtle")
t.pensize(4)
t.color("blue")
t.speed(1)

t.penup()
t.goto(-100, 0)
t.pendown()
t.forward(60)
t.backward(30)
t.right(90)
t.forward(100)

t.left(90)  

t.penup()
t.goto(50, 0)
t.pendown()

t.right(90)
t.forward(100)
t.backward(100)

t.left(90)
t.circle(-25, 180)

t.right(180)
t.circle(-25, 180)

turtle.done()

